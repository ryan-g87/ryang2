#include "PhysicsBody.h"
#include <limits>

PhysicsBody::PhysicsBody(bool isKinematic) : drag(0), mass(0), position(Vector2{ 0,0 }), velocity(Vector2{ 0,0 }), isKinematic(isKinematic) {
	mass = std::numeric_limits<float>::epsilon();
}

Vector2 PhysicsBody::GetPosition() const {
	return position;
}

Vector2 PhysicsBody::GetVelocity() const {
	return velocity;
}

float PhysicsBody::GetDrag() const {
	return drag;
}

float PhysicsBody::GetMass() const {
	return mass;
}

bool PhysicsBody::GetKinematic() const {
	return isKinematic;
}

void PhysicsBody::SetPosition(Vector2 value) {
	position = value;
}

void PhysicsBody::SetVelocity(Vector2 value) {
	velocity = value;
}

void PhysicsBody::SetDrag(float value) {
	drag = value;
}

void PhysicsBody::SetMass(float value) {
	mass = value;
}

void PhysicsBody::SetKinematic(bool value) {
	isKinematic = value;
}