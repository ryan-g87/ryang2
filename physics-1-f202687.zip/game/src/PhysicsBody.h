#pragma once
#include <raylib.h>

// Abstract Class
class PhysicsBody
{
public:
	PhysicsBody(bool isKinematic);

	Vector2 GetPosition() const;
	Vector2 GetVelocity() const;
	float GetDrag() const;
	float GetMass() const;
	bool GetKinematic() const;

	void SetPosition(Vector2 value);
	void SetVelocity(Vector2 value);
	void SetDrag(float value);
	void SetMass(float value);
	virtual void SetKinematic(bool value);
protected:
	Vector2 position, velocity;
	float drag, mass;

	bool isKinematic;
};

