#pragma once

struct Record {
	double angle;
	double range;
	double time;
};