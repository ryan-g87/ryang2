#include <raylib.h>
#include <raymath.h>
#include <raygui.h>

#include "record.h"
#include "PhysicsSimulation.h"

constexpr Vector2 gravity{ 0, 20 };

int main()
{
    PhysicsSimulation world(gravity);

    Record inputRecords[] = {
        {0,         0, 0},
        {3.189685, 80, 0.668},
        {6.4199,  160, 1.342},
        {9.7355,  240, 2.029},
        {13.194,  320, 2.739},
        {16.8745, 400, 3.483},
        {20.905,  480, 4.282},
        {25.529,  560, 5.172},
        {31.367,  640, 6.246},
        {45,      720, 8.485}
    };
    
    Record outputRecords[10];
    for (size_t i = 0; i < 10; ++i) {
        outputRecords[i].angle = inputRecords[i].angle;

        PhysicsBody* body = new PhysicsBody(false);
        body->SetMass(10);
        body->SetPosition(Vector2{ 0, 800 });
        body->SetVelocity(Vector2{ (float)sin((inputRecords[i].angle + 90) * DEG2RAD) * 120,(float)cos((inputRecords[i].angle + 90) * DEG2RAD) * 120 });

        world.AddBody(body);
    }

    InitWindow(1000, 800, "Physics-1");
    InitAudioDevice();
    SetTargetFPS(60);

    while (!WindowShouldClose())
    {
        BeginDrawing();
        ClearBackground(WHITE);

        DrawCircleV(GetMousePosition(), 20.0f, RED);

        float deltaTime = GetFrameTime();
        world.Update(deltaTime);
        world.Draw();

        float step = deltaTime / 4;

        if(step > 0)
            for (size_t i = 0; i < 10; ++i) {
                Vector2 point{ 0, 800 };
                Vector2 velocity{ (float)sin((inputRecords[i].angle + 90) * DEG2RAD) * 120,(float)cos((inputRecords[i].angle + 90) * DEG2RAD) * 120 };

                while(point.y < 801) {
                    velocity.x += gravity.x * step;
                    velocity.y += gravity.y * step;

                    Vector2 position = point;
                    position.x += velocity.x * step;
                    position.y += velocity.y * step;

                    DrawLine(point.x, point.y, position.x, position.y, RED);
                    point = position;
                }
            }

        EndDrawing();
    }

    CloseAudioDevice();
    CloseWindow();
    return 0;
}
