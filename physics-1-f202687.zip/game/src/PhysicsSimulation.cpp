#include "PhysicsSimulation.h"

#include <string>
#include <stdexcept>

PhysicsSimulation::PhysicsSimulation() {
	deltaTime = 0;
	time = 0;
	gravity = Vector2{ 0, 0 };
}

PhysicsSimulation::PhysicsSimulation(Vector2 gravity) {
	deltaTime = 0;
	time = 0;
	this->gravity = gravity;
}

PhysicsSimulation::~PhysicsSimulation()
{
	for (PhysicsBody* object : objects) {
		delete object;
	}
	objects.clear();
}

float PhysicsSimulation::GetDeltaTime() const {
	return deltaTime;
}

float PhysicsSimulation::GetTime() const {
	return time;
}

Vector2 PhysicsSimulation::GetGravity() const {
	return gravity;
}

PhysicsBody* PhysicsSimulation::GetBody(int index) const
{
	return objects.at(index);
}

void PhysicsSimulation::SetGravity(Vector2 direction) {
	gravity = direction;
}

void PhysicsSimulation::AddBody(PhysicsBody* body)
{
	objects.push_back(body);
}

void PhysicsSimulation::Update(float delta)
{
	deltaTime = delta;
	time += delta;

	for (int i = objects.size() - 1; i >= 0; --i) {
		PhysicsBody* body = objects.at(i);

		if (!body->GetKinematic()) {
			Vector2 velocity = body->GetVelocity();
			velocity.x += gravity.x * deltaTime;
			velocity.y += gravity.y * deltaTime;
			body->SetVelocity(velocity);

			Vector2 position = body->GetPosition();
			position.x += velocity.x * deltaTime;
			position.y += velocity.y * deltaTime;
			body->SetPosition(position);

			if (position.y > GetScreenHeight()) {
				body->SetKinematic(true);
				continue; // Don't check collision if it's gone
			}
		}
	}
}

void PhysicsSimulation::Draw()
{
	for (size_t i = 0; i < objects.size(); ++i) {
		PhysicsBody* body = objects.at(i);
		Color c = BLACK;
		DrawCircle(body->GetPosition().x, body->GetPosition().y, body->GetMass(), c);

		if (body->GetKinematic()) {
			// Draw Mark
			DrawLine(body->GetPosition().x, 600 + i * 20, body->GetPosition().x, 800, BLACK);
			DrawText(std::to_string(body->GetPosition().x).c_str(), body->GetPosition().x, 580 + i * 20, 20, BLACK);
		}
	}
}
